import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, 
  Share2, 
  User, 
  Gamepad2, 
  Plus, 
  Play, 
  Home,
  Loader2, 
  LogOut,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Send,
  Trash2,
  Maximize2,
  ArrowLeft,
  X,
  Settings,
  UserPlus,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from './lib/AuthContext';
import { db, handleFirestoreError, OperationType } from './lib/firebase';
import { 
  collection, 
  query, 
  orderBy, 
  limit, 
  getDocs, 
  addDoc, 
  serverTimestamp, 
  doc, 
  updateDoc, 
  increment,
  setDoc,
  deleteDoc,
  getDoc,
  where,
  onSnapshot
} from 'firebase/firestore';
import { generateGame, updateGame } from './services/geminiService';
import { GamePlayer } from './components/GamePlayer';
import { cn } from './lib/utils';
import { Eye, Code as CodeIcon, Save, Sparkles, RefreshCw } from 'lucide-react';

// --- Types ---
interface GameData {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorAvatarUrl?: string;
  title: string;
  prompt: string;
  code: string;
  thumbnailUrl: string;
  likesCount: number;
  sharesCount: number;
  createdAt: any;
}

// --- Components ---

interface Comment {
  id: string;
  uid: string;
  username: string;
  avatarUrl?: string;
  content: string;
  createdAt: any;
}

const showToast = (msg: string) => window.dispatchEvent(new CustomEvent('astara-toast', { detail: msg }));

const CommentSection = ({ gameId, onClose }: { gameId: string; onClose: () => void }) => {
  const { user, profile } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'games', gameId, 'comments'), 
      orderBy('createdAt', 'desc')
    );
    const unsub = onSnapshot(q, (snap) => {
      setComments(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comment)));
      setLoading(false);
    });
    return () => unsub();
  }, [gameId]);

  const handlePost = async () => {
    if (!text.trim() || !user || !profile) return;
    const content = text.trim();
    setText('');
    showToast("Yorumunuz eklendi!");
    try {
      await addDoc(collection(db, 'games', gameId, 'comments'), {
        uid: user.uid,
        username: profile.username || user.displayName || 'Gezgin',
        avatarUrl: profile.avatarUrl || '',
        content,
        createdAt: serverTimestamp()
      });
    } catch (e) {
      console.error(e);
    }
  };

  const handleDelete = async (commentId: string) => {
    try {
      await deleteDoc(doc(db, 'games', gameId, 'comments', commentId));
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <motion.div 
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 250 }}
      className="fixed inset-0 z-[1000] bg-black flex flex-col"
    >
      <div className="bg-black/90 backdrop-blur-xl border-b border-white/5 py-4 px-6 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center text-white/50 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
          <h3 className="text-sm font-black tracking-widest uppercase">Topluluk <span className="text-purple-500 ml-1">{comments.length}</span></h3>
        </div>
      </div>

      <div className="bg-black/95 border-b border-white/5 p-4 sticky top-[72px] z-50 backdrop-blur-md">
        <div className="flex gap-3 items-center bg-zinc-900 border border-white/10 rounded-2xl p-1.5 pr-2 focus-within:border-purple-500/50 transition-all">
          <textarea 
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Düşünceni paylaş..."
            className="flex-1 bg-transparent border-none rounded-2xl p-2 text-sm text-white focus:outline-none resize-none max-h-32"
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handlePost())}
          />
          <button 
            onClick={handlePost} 
            disabled={!text.trim()} 
            className="w-9 h-9 bg-purple-600 text-white rounded-xl flex items-center justify-center active:scale-95 transition-all disabled:opacity-30 disabled:grayscale"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 space-y-8 pt-8 pb-32">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
            <p className="text-[10px] font-black text-white/20 uppercase tracking-widest">Yükleniyor</p>
          </div>
        ) : comments.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 text-center space-y-6">
            <div className="w-20 h-20 bg-zinc-900 rounded-[35px] flex items-center justify-center">
              <MessageSquare className="w-8 h-8 text-white/5" />
            </div>
            <div className="space-y-2">
              <p className="text-white/40 font-black text-sm tracking-tight uppercase">Sohbeti Başlat</p>
              <p className="text-white/20 text-xs font-medium">Bu oyun hakkında ilk yorumu sen yaz.</p>
            </div>
          </div>
        ) : comments.map(c => (
          <div key={c.id} className="flex gap-4 items-start group">
            <div 
              className="w-10 h-10 rounded-2xl overflow-hidden bg-zinc-900 border border-white/5 flex-shrink-0"
              onClick={() => showToast(`@${c.username} profili yakında!`)}
            >
              <img 
                src={c.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${c.uid}`} 
                className="w-full h-full object-cover" 
                alt="Avatar" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-black text-purple-500 tracking-widest uppercase leading-none">@{c.username}</p>
                {user?.uid === c.uid && (
                  <button onClick={() => handleDelete(c.id)} className="text-white/10 hover:text-red-500 transition-colors p-1">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <div className="bg-zinc-900 border border-white/5 rounded-2xl p-4 shadow-sm">
                <p className="text-white/90 text-[13px] leading-relaxed font-medium">{c.content}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

interface AuthScreenProps {
  onLogin: () => void;
}

const GameSettingsModal = ({ game, onClose }: { game: GameData; onClose: () => void }) => {
  const [title, setTitle] = useState(game.title || "Adsız Oyun");
  const [thumbnailUrl, setThumbnailUrl] = useState(game.thumbnailUrl || "");
  const [loading, setLoading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleUpdate = async () => {
    if (!title.trim()) {
      showToast("Lütfen bir isim girin.");
      return;
    }
    setLoading(true);
    try {
      await updateDoc(doc(db, 'games', game.id), {
        title: title.trim(),
        thumbnailUrl: thumbnailUrl.trim()
      });
      showToast("Oyun güncellendi!");
      onClose();
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `games/${game.id}`);
      showToast("Güncelleme başarısız.");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    setLoading(true);
    try {
      await deleteDoc(doc(db, 'games', game.id));
      showToast("Oyun silindi.");
      onClose();
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `games/${game.id}`);
      showToast("Silme işlemi başarısız.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="w-full max-w-sm bg-zinc-900 border border-white/10 rounded-[40px] p-8 space-y-8 shadow-2xl relative overflow-hidden"
      >
        <AnimatePresence mode="wait">
          {!confirmDelete ? (
            <motion.div 
              key="settings"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black tracking-tight uppercase">Oyun Ayarları</h3>
                <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-white/40 uppercase tracking-widest pl-1">Görsel URL</label>
                  <input 
                    type="text" 
                    value={thumbnailUrl} 
                    onChange={(e) => setThumbnailUrl(e.target.value)}
                    className="w-full bg-black border border-white/5 rounded-2xl p-4 text-sm focus:outline-none focus:border-purple-500 transition-all font-medium"
                    placeholder="https://..."
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-white/40 uppercase tracking-widest pl-1">Oyun İsmi</label>
                  <input 
                    type="text" 
                    value={title} 
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-black border border-white/5 rounded-2xl p-4 text-sm focus:outline-none focus:border-purple-500 transition-all font-medium"
                  />
                </div>
              </div>

              <div className="space-y-3 pt-4">
                <button 
                  disabled={loading}
                  onClick={handleUpdate}
                  className="w-full py-4 bg-white text-black font-black rounded-2xl active:scale-[0.98] transition-all disabled:opacity-50"
                >
                  {loading ? "GÜNCELLENİYOR..." : "KAYDET"}
                </button>
                
                <button 
                  disabled={loading}
                  onClick={() => setConfirmDelete(true)}
                  className="w-full py-4 bg-red-500/10 text-red-500 font-black rounded-2xl hover:bg-red-500/20 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  SİL
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="confirm"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-8 text-center py-4"
            >
              <div className="w-20 h-20 bg-red-500/10 rounded-[35px] flex items-center justify-center mx-auto">
                <Trash2 className="w-8 h-8 text-red-500" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-xl font-black uppercase">Emin misin?</h3>
                <p className="text-white/40 text-sm font-medium leading-relaxed">
                  Bu oyunu sildiğinde tüm veriler kalıcı olarak yok olacak.
                </p>
              </div>

              <div className="space-y-3 pt-4">
                <button 
                  disabled={loading}
                  onClick={handleDelete}
                  className="w-full py-4 bg-red-500 text-white font-black rounded-2xl active:scale-[0.98] transition-all disabled:opacity-50"
                >
                  {loading ? "SİLİNİYOR..." : "EVET, SİL"}
                </button>
                
                <button 
                  disabled={loading}
                  onClick={() => setConfirmDelete(false)}
                  className="w-full py-4 bg-zinc-800 text-white/60 font-black rounded-2xl hover:bg-zinc-700 transition-all active:scale-[0.98]"
                >
                  VAZGEÇ
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
};

const AuthScreen = ({ onLogin }: AuthScreenProps) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white p-6 relative overflow-hidden">
      <div className="absolute top-0 inset-x-0 h-96 bg-gradient-to-b from-purple-900/20 to-transparent pointer-events-none" />
      
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 flex flex-col items-center text-center space-y-12 w-full max-w-sm"
      >
        <div className="space-y-6">
          <div className="w-24 h-24 bg-zinc-900 border border-white/5 rounded-[40px] flex items-center justify-center mx-auto shadow-2xl">
             <div className="w-12 h-12 bg-white rounded-full" />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-black tracking-tight uppercase">Astara</h1>
            <p className="text-white/40 text-sm font-medium tracking-widest uppercase">Hayal et, Üret, Oyna</p>
          </div>
        </div>

        <div className="space-y-4 w-full">
          <button 
            onClick={onLogin}
            className="w-full py-5 bg-white text-black font-black text-sm rounded-2xl flex items-center justify-center gap-4 active:scale-[0.98] transition-all"
          >
            Google ile Giriş Yap
          </button>
          <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest">Topluluğa Katıl</p>
        </div>
      </motion.div>
    </div>
  );
};

interface GameCardProps {
  game: GameData;
  onFullscreen: () => void;
  onViewProfile: (uid: string) => void;
  key?: string | number;
}

const GameCard = ({ game, onFullscreen, onViewProfile }: GameCardProps) => {
  const { user } = useAuth();
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(game.likesCount);
  const [showPlayer, setShowPlayer] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [commentCount, setCommentCount] = useState(0);

  useEffect(() => {
    if (user) {
      const checkLike = async () => {
        const likeRef = doc(db, 'games', game.id, 'likes', user.uid);
        const likeSnap = await getDoc(likeRef);
        setLiked(likeSnap.exists());
      };
      checkLike();

      const commentsRef = collection(db, 'games', game.id, 'comments');
      const unsubComments = onSnapshot(commentsRef, (snap) => {
        setCommentCount(snap.size);
      });
      return () => unsubComments();
    }
  }, [user, game.id]);

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Astara Play: ${game.title}`,
          text: `Check out this AI-generated game: ${game.title}`,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        showToast("Bağlantı kopyalandı!");
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.error(err);
      }
    }
  };

  const toggleLike = async () => {
    if (!user) return;
    const likeRef = doc(db, 'games', game.id, 'likes', user.uid);
    const gameRef = doc(db, 'games', game.id);
    
    try {
      if (liked) {
        setLiked(false);
        setLikes(prev => prev - 1);
        await deleteDoc(likeRef);
        await updateDoc(gameRef, { likesCount: increment(-1) });
      } else {
        setLiked(true);
        setLikes(prev => prev + 1);
        await setDoc(likeRef, { userId: user.uid, gameId: game.id, createdAt: serverTimestamp() });
        await updateDoc(gameRef, { likesCount: increment(1) });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `games/${game.id}/likes`);
    }
  };

  return (
    <div className="relative w-full h-full snap-start overflow-hidden bg-[#0c0c1e] group">
      <AnimatePresence mode="wait">
        {!showPlayer ? (
          <motion.div 
            key="thumbnail"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full relative bg-zinc-900"
          >
            {game.thumbnailUrl ? (
              <img 
                src={game.thumbnailUrl} 
                className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 transition-all duration-700"
                alt={game.title}
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center gap-4">
                <div className="w-8 h-8 rounded-full border-2 border-white/5 border-t-purple-500 animate-spin" />
                <p className="text-[8px] font-black uppercase tracking-[0.3em] text-white/20">Ekran Görüntüsü Alınıyor</p>
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-[#0c0c1e]" />
            
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <button 
                onClick={() => setShowPlayer(true)}
                className="w-24 h-24 bg-zinc-900 border border-zinc-800 rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all group/btn shadow-2xl"
              >
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center group-hover/btn:bg-purple-500 transition-colors">
                   <Play className="w-8 h-8 text-black fill-black group-hover/btn:text-white group-hover/btn:fill-white" />
                </div>
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="player"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full h-full bg-black"
          >
            <GamePlayer code={game.code} />
            <button 
              onClick={() => setShowPlayer(false)}
              className="absolute top-20 left-6 z-50 glass p-3 rounded-2xl text-white hover:bg-white/20 transition-colors"
            >
              <ChevronUp className="w-6 h-6 rotate-[-90deg]" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Info & Actions */}
      <div className="absolute bottom-28 left-6 right-24 pointer-events-none space-y-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => onViewProfile(game.creatorId)}
            className="w-12 h-12 rounded-2xl pointer-events-auto shadow-2xl bg-zinc-900 border border-zinc-800 overflow-hidden active:scale-95 transition-all"
          >
            {game.creatorAvatarUrl ? (
              <img 
                src={game.creatorAvatarUrl} 
                className="w-full h-full object-cover" 
                alt="Avatar"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full bg-zinc-800 flex items-center justify-center font-black text-xl text-white">
                {game.creatorName[0].toUpperCase()}
              </div>
            )}
          </button>
          <div className="pointer-events-auto">
            <h4 
              onClick={() => onViewProfile(game.creatorId)}
              className="font-black text-white text-lg tracking-tight cursor-pointer hover:text-purple-400 transition-colors"
            >
              @{game.creatorName}
            </h4>
            <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest">Geliştirici</p>
          </div>
        </div>
        
        <div className="bg-zinc-900/80 border border-white/5 p-5 rounded-3xl pointer-events-auto">
           <p className="text-white/80 text-sm font-medium leading-relaxed line-clamp-2">
            {game.prompt}
          </p>
        </div>
      </div>

      <div className="absolute bottom-28 right-6 flex flex-col gap-6 items-center">
        <button onClick={toggleLike} className="flex flex-col items-center gap-2 group pointer-events-auto">
          <div className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center transition-all border shadow-2xl",
            liked 
              ? "bg-red-500/10 border-red-500/30" 
              : "bg-zinc-900 border-zinc-800 hover:bg-zinc-800"
          )}>
            <Heart className={cn("w-6 h-6 transition-all", liked ? "fill-red-500 text-red-500 scale-110" : "text-white")} />
          </div>
          <span className="text-white text-[10px] font-black drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">{likes >= 1000 ? (likes/1000).toFixed(1) + 'k' : likes}</span>
        </button>

        <button onClick={() => setShowComments(true)} className="flex flex-col items-center gap-2 group pointer-events-auto">
          <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center shadow-2xl hover:bg-zinc-800 transition-all">
            <MessageSquare className="w-6 h-6 text-white" />
          </div>
          <span className="text-white text-[10px] font-black drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">{commentCount}</span>
        </button>

        <button onClick={onFullscreen} className="flex flex-col items-center gap-2 group pointer-events-auto">
          <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center shadow-2xl hover:bg-zinc-800 transition-all">
            <Maximize2 className="w-6 h-6 text-white" />
          </div>
          <span className="text-white text-[10px] font-black drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] uppercase tracking-tighter">Ekran</span>
        </button>

        <AnimatePresence>
          {showComments && (
            <CommentSection gameId={game.id} onClose={() => setShowComments(false)} />
          )}
        </AnimatePresence>

        <button 
          onClick={handleShare}
          className="flex flex-col items-center gap-2 group pointer-events-auto"
        >
          <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center shadow-2xl hover:bg-zinc-800 transition-all">
            <Share2 className="w-6 h-6 text-white" />
          </div>
          <span className="text-white text-[10px] font-black drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] uppercase tracking-tighter">Paylaş</span>
        </button>
      </div>
    </div>
  );
};

const HomeFeed = ({ onFullscreen, onViewProfile }: { onFullscreen: (game: GameData) => void; onViewProfile: (uid: string) => void }) => {
  const [games, setGames] = useState<GameData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchGames = async () => {
      const q = query(collection(db, 'games'), orderBy('createdAt', 'desc'), limit(10));
      const snap = await getDocs(q);
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as GameData));
      setGames(data);
      setLoading(false);
    };
    fetchGames();
  }, []);

  if (loading) return (
    <div className="h-full flex items-center justify-center bg-black">
      <Loader2 className="w-10 h-10 text-white animate-spin" />
    </div>
  );

  return (
    <div className="h-full overflow-y-scroll snap-y snap-mandatory scroll-smooth">
      {games.map(game => (
        <GameCard key={game.id} game={game} onFullscreen={() => onFullscreen(game)} onViewProfile={onViewProfile} />
      ))}
      {games.length === 0 && (
        <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-4">
          <Gamepad2 className="w-16 h-16 opacity-20" />
          <p>Henüz oyun yok. İlk oyunu sen oluştur!</p>
        </div>
      )}
    </div>
  );
};

interface CreateViewProps {
  onDone: () => void;
}

interface ChatMessage {
  role: 'user' | 'ai';
  content: string;
}

const CreateView = ({ onDone }: CreateViewProps) => {
  const { user, profile } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [currentCode, setCurrentCode] = useState<string | null>(null);
  const [gameInfo, setGameInfo] = useState<{ title: string; description: string; thumbnailUrl: string } | null>(null);
  const [viewMode, setViewMode] = useState<'chat' | 'preview'>('chat');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !user || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      if (!currentCode) {
        setStatus('Gemini oyununu tasarlıyor...');
        const generated = await generateGame(userMessage);
        setCurrentCode(generated.code);
        setGameInfo({
          title: generated.title,
          description: generated.description,
          thumbnailUrl: generated.thumbnailUrl
        });
        setMessages(prev => [...prev, { role: 'ai', content: `Harika! "${generated.title}" oyunun hazır. Sağ üstten önizlemeye bakabilirsin veya değişiklik isteyebilirsin.` }]);
      } else {
        setStatus('Kod güncelleniyor...');
        const updated = await updateGame(currentCode, userMessage);
        setCurrentCode(updated.code);
        setGameInfo(prev => prev ? { ...prev, title: updated.title, description: updated.description } : null);
        setMessages(prev => [...prev, { role: 'ai', content: 'Değişiklikleri uyguladım. Önizleyebilirsin!' }]);
      }
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'ai', content: 'Hata oluştu, lütfen tekrar dener misin?' }]);
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  const handleSave = async () => {
    if (!currentCode || !gameInfo || !user) return;
    
    const finalThumbnailUrl = gameInfo.thumbnailUrl || "";

    // Check document size (Firestore limit is 1MB)
    const payload = {
      creatorId: user.uid,
      creatorName: user.displayName || user.email?.split('@')[0],
      creatorAvatarUrl: profile?.avatarUrl || null,
      title: gameInfo.title,
      prompt: messages[0]?.content || "AI Game",
      code: currentCode,
      thumbnailUrl: finalThumbnailUrl,
      likesCount: 0,
      sharesCount: 0,
      createdAt: new Date() // placeholder for size check
    };
    
    const estimatedSize = new Blob([JSON.stringify(payload)]).size;
    const MAX_SIZE = 1048576; // 1MB

    if (estimatedSize > MAX_SIZE) {
      showToast(`Oyun çok büyük (${(estimatedSize / 1024 / 1024).toFixed(2)}MB). Maksimum 1MB izin veriliyor. Lütfen daha az görsel veya daha kısa kod isteyin.`);
      return;
    }

    setLoading(true);
    setStatus('Galaksiye kaydediliyor...');
    try {
      await addDoc(collection(db, 'games'), {
        creatorId: user.uid,
        creatorName: user.displayName || user.email?.split('@')[0],
        creatorAvatarUrl: profile?.avatarUrl || null,
        title: gameInfo.title,
        prompt: messages[0]?.content || "AI Game",
        code: currentCode,
        thumbnailUrl: finalThumbnailUrl,
        likesCount: 0,
        sharesCount: 0,
        createdAt: serverTimestamp()
      });
      showToast("Oyun başarıyla yayınlandı!");
      onDone();
    } catch (error) {
      console.error(error);
      showToast("Kayıt başarısız.");
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="h-full flex flex-col bg-black relative">
      {/* Header with toggle */}
      <div className="absolute top-20 left-0 right-0 z-50 px-6 flex justify-between items-center bg-black/50 backdrop-blur-md py-4 border-y border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
          <span className="text-[10px] font-black uppercase tracking-widest text-white/50">Ultra Dev Mode</span>
        </div>
        
        <div className="flex items-center gap-2">
          {currentCode && (
            <div className="flex bg-zinc-900 rounded-xl p-1 border border-white/5">
              <button 
                onClick={() => setViewMode('chat')}
                className={cn(
                  "px-3 py-1.5 rounded-lg flex items-center gap-2 transition-all",
                  viewMode === 'chat' ? "bg-white text-black font-black" : "text-white/40 font-bold"
                )}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span className="text-[10px] uppercase">SOHBET</span>
              </button>
              <button 
                onClick={() => setViewMode('preview')}
                className={cn(
                  "px-3 py-1.5 rounded-lg flex items-center gap-2 transition-all",
                  viewMode === 'preview' ? "bg-white text-black font-black" : "text-white/40 font-bold"
                )}
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="text-[10px] uppercase">ÖNİZLEME</span>
              </button>
            </div>
          )}
          
          {currentCode && (
            <button 
              onClick={handleSave}
              className="px-4 py-2 bg-purple-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 active:scale-95 transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              Yayınla
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 mt-36 mb-24 overflow-hidden relative">
        {viewMode === 'chat' ? (
          <div className="h-full flex flex-col px-6">
            <div className="flex-1 overflow-y-auto space-y-6 py-6 custom-scrollbar">
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
                  <div className="w-24 h-24 bg-gradient-to-tr from-purple-600 to-pink-500 rounded-[45px] flex items-center justify-center shadow-2xl relative">
                    <Sparkles className="w-10 h-10 text-white" />
                    <div className="absolute -inset-4 bg-purple-500/20 blur-3xl -z-10" />
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-3xl font-black italic tracking-tighter">HADİ ÜRETELİM</h3>
                    <p className="text-white/40 text-sm font-medium leading-relaxed max-w-[240px] mx-auto">
                      Nasıl bir oyun hayal ediyorsun? Bana anlat, Gemini hemen kodlasın.
                    </p>
                  </div>
                  <div className="flex flex-wrap justify-center gap-2">
                    {['Uzay macerası', 'Retro platform', 'Siyah beyaz bulmaca'].map(suggestion => (
                      <button 
                        key={suggestion}
                        onClick={() => setInput(suggestion)}
                        className="px-4 py-2 rounded-full border border-white/5 bg-white/5 text-[10px] font-bold text-white/40 hover:text-white hover:bg-white/10 transition-all"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              {messages.map((m, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex flex-col max-w-[85%]",
                    m.role === 'user' ? "ml-auto items-end" : "mr-auto items-start"
                  )}
                >
                  <div className={cn(
                    "p-4 rounded-3xl text-sm font-medium leading-relaxed",
                    m.role === 'user' 
                      ? "bg-purple-600 text-white rounded-tr-none" 
                      : "bg-zinc-900 border border-white/5 rounded-tl-none text-white/90"
                  )}>
                    {m.content}
                  </div>
                  <span className="text-[8px] font-black uppercase text-white/20 mt-2 tracking-widest">
                    {m.role === 'user' ? 'Geliştirici' : 'Gemini AI'}
                  </span>
                </motion.div>
              ))}
              
              {loading && (
                <div className="flex gap-3 items-center mr-auto">
                  <div className="flex gap-1.5">
                    <div className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-bounce" />
                    <div className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
                  </div>
                  <span className="text-[10px] font-black italic text-white/30 truncate">{status}</span>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          </div>
        ) : (
          <div className="h-full bg-black relative animate-in fade-in duration-500">
            {currentCode && (
              <GamePlayer 
                code={currentCode} 
                onThumbnailCaptured={(dataUrl) => {
                  setGameInfo(prev => prev ? { ...prev, thumbnailUrl: dataUrl } : null);
                }}
              />
            )}
            
            <div className="absolute top-6 left-6 flex flex-col gap-2 pointer-events-none">
              <div className="glass px-4 py-2 rounded-xl">
                 <h4 className="text-[10px] font-black uppercase tracking-widest text-purple-400 mb-0.5">Oyun Adı</h4>
                 <p className="text-sm font-bold truncate max-w-[160px]">{gameInfo?.title}</p>
              </div>
            </div>

            <button 
              onClick={() => setViewMode('chat')}
              className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 glass px-6 py-3 rounded-2xl hover:bg-white/10 transition-all font-black text-[10px] uppercase tracking-widest active:scale-95"
            >
              <MessageSquare className="w-4 h-4" />
              SOHBETE DÖN
            </button>
          </div>
        )}
      </div>

      {/* Input Area */}
      {viewMode === 'chat' && (
        <div className="absolute bottom-28 inset-x-0 p-6 pt-0 bg-gradient-to-t from-black via-black/80 to-transparent">
          <div className="flex gap-3 items-center bg-zinc-900 border border-white/10 rounded-[30px] p-2 pr-2.5 shadow-2xl focus-within:border-purple-500 transition-all">
            <textarea 
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={currentCode ? "Değişiklik iste..." : "Bir oyun hayal et..."}
              className="flex-1 bg-transparent border-none rounded-3xl p-4 text-sm text-white focus:outline-none resize-none"
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
            />
            <button 
              onClick={handleSend}
              disabled={loading || !input.trim()}
              className="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center active:scale-90 transition-all disabled:opacity-20 shadow-lg"
            >
              {loading ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const ProfileView = ({ 
  userId, 
  onFullscreen, 
  onBack 
}: { 
  userId?: string; 
  onFullscreen: (game: GameData) => void;
  onBack?: () => void;
}) => {
  const { user: currentUser, profile: currentProfile, logout } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [games, setGames] = useState<GameData[]>([]);
  const [loading, setLoading] = useState(true);
  const [isChangingAvatar, setIsChangingAvatar] = useState(false);
  const [editingGame, setEditingGame] = useState<GameData | null>(null);
  const [avatarTab, setAvatarTab] = useState<'icons' | 'device'>('icons');
  const [isUploading, setIsUploading] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);

  const isOwnProfile = !userId || userId === currentUser?.uid;
  const targetId = userId || currentUser?.uid;

  useEffect(() => {
    if (!isOwnProfile && currentUser && targetId) {
      const checkFollow = async () => {
        const followDoc = await getDoc(doc(db, 'follows', `${currentUser.uid}_${targetId}`));
        setIsFollowing(followDoc.exists());
      };
      checkFollow();
    }
  }, [userId, currentUser, targetId, isOwnProfile]);

  const handleFollow = async () => {
    if (!currentUser || !targetId || followLoading) return;
    setFollowLoading(true);
    const followId = `${currentUser.uid}_${targetId}`;
    try {
      if (isFollowing) {
        await deleteDoc(doc(db, 'follows', followId));
        await updateDoc(doc(db, 'users', targetId), { followersCount: increment(-1) });
        setIsFollowing(false);
      } else {
        await setDoc(doc(db, 'follows', followId), {
          followerId: currentUser.uid,
          followingId: targetId,
          createdAt: serverTimestamp()
        });
        await updateDoc(doc(db, 'users', targetId), { followersCount: increment(1) });
        setIsFollowing(true);
        showToast("Takip edildi!");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setFollowLoading(false);
    }
  };

  const defaultIcons = [
    'https://api.dicebear.com/7.x/bottts/svg?seed=Felix',
    'https://api.dicebear.com/7.x/avataaars/svg?seed=Anya',
    'https://api.dicebear.com/7.x/pixel-art/svg?seed=Mario',
    'https://api.dicebear.com/7.x/shapes/svg?seed=Abstract',
    'https://api.dicebear.com/7.x/big-smile/svg?seed=Happy',
    'https://api.dicebear.com/7.x/croodles/svg?seed=Art',
    'https://api.dicebear.com/7.x/micah/svg?seed=Minimal',
    'https://api.dicebear.com/7.x/notionists/svg?seed=Clean',
  ];

  useEffect(() => {
    if (!targetId) return;

    const unsubProfile = onSnapshot(doc(db, 'users', targetId), (snap) => {
      if (snap.exists()) {
        setProfile(snap.data());
      }
    });

    const q = query(collection(db, 'games'), where('creatorId', '==', targetId), orderBy('createdAt', 'desc'));
    const unsubGames = onSnapshot(q, (snap) => {
      setGames(snap.docs.map(d => ({ id: d.id, ...d.data() } as GameData)));
      setLoading(false);
    }, (err) => {
      console.error(err);
      setLoading(false);
    });
    return () => {
      unsubProfile();
      unsubGames();
    };
  }, [targetId, currentProfile, isOwnProfile]);

  const updateAvatar = async (url: string) => {
    if (!currentUser) return;
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), { avatarUrl: url });
      setIsChangingAvatar(false);
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    if (file.size > 1.5 * 1024 * 1024) {
      alert("Fotoğraf çok büyük (Max 1.5MB)");
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = event.target?.result as string;
      try {
        await updateDoc(doc(db, 'users', currentUser.uid), { avatarUrl: base64 });
        setIsUploading(false);
        setIsChangingAvatar(false);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  if (!currentUser || !profile) return null;

  return (
    <div className="h-full flex flex-col relative overflow-hidden">
      {!isOwnProfile && onBack && (
        <div className="fixed top-0 left-0 right-0 z-[600] pointer-events-none p-6 pt-[calc(var(--safe-top)+1rem)] flex justify-start">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-white active:scale-90 transition-all hover:bg-zinc-800 pointer-events-auto shadow-2xl"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
        </div>
      )}
      
      <div className="flex-1 overflow-y-auto p-8 pt-[calc(var(--safe-top)+7rem)]">
        <div className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-5">
          <div className="relative z-30">
            <div className="w-24 h-24 rounded-[35px] glass p-[3px] shadow-2xl overflow-hidden flex items-center justify-center bg-zinc-900 border border-white/10">
              <img 
                key={profile?.avatarUrl}
                src={profile?.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${targetId}`} 
                className="w-full h-full object-cover rounded-[32px]"
                alt="Avatar"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${targetId}`;
                }}
              />
            </div>
            {isOwnProfile && (
              <button 
                onClick={() => setIsChangingAvatar(true)}
                className="absolute -bottom-2 -right-2 bg-gradient-to-tr from-purple-600 to-pink-500 p-2.5 rounded-xl border-2 border-[#0c0c1e] shadow-lg hover:scale-110 transition-all cursor-pointer z-50 active:scale-90"
              >
                <Plus className="w-4 h-4 text-white" />
              </button>
            )}
          </div>
          <div className="space-y-1">
            <h2 className="text-3xl font-black tracking-tight leading-none">
              {profile?.username || (isOwnProfile ? currentUser?.displayName : 'Gezgin') || 'Gezgin'}
            </h2>
            <div className="px-3 py-1 bg-white/10 rounded-full inline-block">
               <p className="text-[10px] font-black text-purple-300 uppercase tracking-widest">
                 {isOwnProfile ? 'Master Creator' : 'Astara Player'}
               </p>
            </div>
          </div>
        </div>
        {isOwnProfile && (
          <button 
            onClick={logout}
            className="glass-dark p-4 rounded-2xl text-white/50 hover:text-white hover:bg-white/10 transition-all z-40 active:scale-90"
          >
            <LogOut className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Avatar Modal Overlay */}
      <AnimatePresence>
        {editingGame && (
          <GameSettingsModal 
            game={editingGame} 
            onClose={() => setEditingGame(null)} 
          />
        )}
        {isChangingAvatar && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="w-full max-w-sm glass-dark rounded-[40px] p-6 border border-white/10 shadow-2xl relative"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-black italic">PROFİLİ GÜNCELLE</h3>
                <button onClick={() => setIsChangingAvatar(false)} className="text-white/30 hover:text-white bg-white/5 p-2 rounded-xl transition-colors">
                  <Plus className="rotate-45" />
                </button>
              </div>

              {/* Tabs */}
              <div className="flex gap-2 p-1 bg-white/5 rounded-2xl mb-6">
                <button 
                  onClick={() => setAvatarTab('icons')}
                  className={cn(
                    "flex-1 py-3 rounded-xl text-xs font-black transition-all",
                    avatarTab === 'icons' ? "bg-white text-black shadow-lg" : "text-white/40 hover:text-white"
                  )}
                >
                  ICONS
                </button>
                <button 
                  onClick={() => setAvatarTab('device')}
                  className={cn(
                    "flex-1 py-3 rounded-xl text-xs font-black transition-all",
                    avatarTab === 'device' ? "bg-white text-black shadow-lg" : "text-white/40 hover:text-white"
                  )}
                >
                  MY DEVICE
                </button>
              </div>

              {/* Tab Content */}
              <div className="min-h-[260px]">
                {avatarTab === 'icons' ? (
                  <div className="grid grid-cols-4 gap-3">
                    {defaultIcons.map((url, i) => (
                      <button 
                        key={i}
                        onClick={() => updateAvatar(url)}
                        className="w-full aspect-square rounded-2xl overflow-hidden border-2 border-transparent hover:border-purple-500 transition-all hover:scale-105 bg-white/5 p-1"
                      >
                        <img src={url} className="w-full h-full object-cover rounded-xl" alt="Icon" />
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center min-h-[240px] gap-4">
                    <label className="w-full h-40 border-2 border-dashed border-white/10 rounded-3xl flex flex-col items-center justify-center cursor-pointer hover:border-purple-500 hover:bg-purple-500/5 transition-all group">
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleFileUpload}
                      />
                      {isUploading ? (
                        <div className="flex flex-col items-center gap-3">
                          <Loader2 className="w-10 h-10 animate-spin text-purple-400" />
                          <span className="text-[10px] font-black text-purple-400">YÜKLENİYOR...</span>
                        </div>
                      ) : (
                        <>
                          <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform bg-gradient-to-tr from-purple-500/20 to-pink-500/20">
                            <Plus className="text-white" />
                          </div>
                          <span className="text-xs font-black text-white/40 group-hover:text-white uppercase tracking-widest">Fotoğraf Seç</span>
                        </>
                      )}
                    </label>
                    <p className="text-[10px] text-white/20 text-center px-4 leading-relaxed uppercase tracking-tighter">JPG, PNG, WebP formatlarını seçebilirsin.<br/>Maksimum boyut: 1.5MB</p>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-3 gap-3 bg-zinc-900 border border-white/5 p-5 rounded-3xl mb-10">
        <div className="text-center space-y-1">
          <p className="text-xl font-black">{games.length}</p>
          <p className="text-[9px] text-white/30 uppercase font-black tracking-widest">Oyun</p>
        </div>
        <div className="text-center space-y-1 border-x border-white/10">
          <p className="text-xl font-black">{games.reduce((acc, g) => acc + g.likesCount, 0)}</p>
          <p className="text-[9px] text-white/30 uppercase font-black tracking-widest">Beğeni</p>
        </div>
        <div className="text-center space-y-1">
          <p className="text-xl font-black">{profile?.followersCount || 0}</p>
          <p className="text-[9px] text-white/30 uppercase font-black tracking-widest">Takipçi</p>
        </div>
      </div>

      {!isOwnProfile && (
        <button 
          onClick={handleFollow}
          disabled={followLoading}
          className={cn(
            "w-full py-4 rounded-2xl font-black text-sm transition-all active:scale-95 flex items-center justify-center gap-2 mb-10",
            isFollowing 
              ? "bg-zinc-800 text-white/60 border border-white/5" 
              : "bg-white text-black shadow-xl shadow-white/5"
          )}
        >
          {followLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : isFollowing ? (
            <>
              <Check className="w-5 h-5" />
              TAKİPTESİN
            </>
          ) : (
            <>
              <UserPlus className="w-5 h-5" />
              TAKİP ET
            </>
          )}
        </button>
      )}

      <div className="space-y-6">
        <div className="flex justify-between items-center px-2">
           <h3 className="text-xs font-black text-white/40 uppercase tracking-[0.3em]">
             {isOwnProfile ? 'ÜRETTİĞİM OYUNLAR' : 'OYUNLAR'}
           </h3>
           <ChevronDown className="w-4 h-4 text-white/20" />
        </div>
        
        <div className="grid grid-cols-2 gap-4 pb-10">
          {loading ? (
            <div className="col-span-2 flex justify-center py-20">
              <Loader2 className="w-10 h-10 animate-spin text-purple-900/30" />
            </div>
          ) : games.length > 0 ? games.map(game => (
            <div 
              key={game.id} 
              onClick={() => onFullscreen(game)}
              className="aspect-[4/5] bg-zinc-900 rounded-[30px] overflow-hidden relative group cursor-pointer hover:scale-[1.02] transition-transform shadow-2xl"
            >
              {game.thumbnailUrl ? (
                <img 
                  src={game.thumbnailUrl} 
                  className="w-full h-full object-cover grayscale-[0.5] group-hover:grayscale-0 transition-all duration-500"
                  alt={game.title}
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center gap-2">
                  <div className="w-4 h-4 rounded-full border border-white/10 border-t-purple-500 animate-spin" />
                  <span className="text-[6px] font-black text-white/10 tracking-widest uppercase">Görüntü Bekleniyor</span>
                </div>
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center transition-all bg-gradient-to-t from-black/80 to-transparent">
                 <Play className="w-10 h-10 text-white fill-white mb-2" />
                 <span className="text-[10px] font-black uppercase text-white tracking-widest">OYNA</span>
              </div>
              <div className="absolute top-3 right-3 flex flex-col gap-2">
                <div className="glass p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex items-center gap-1">
                    <Heart className="w-3 h-3 text-red-500 fill-red-500" />
                    <span className="text-[8px] font-bold text-white tracking-tighter">{game.likesCount}</span>
                  </div>
                </div>
                
                {isOwnProfile && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingGame(game);
                    }}
                    className="glass p-2 rounded-xl backdrop-blur-md border border-white/10 hover:bg-white/10 transition-all z-10"
                  >
                    <Settings className="w-4 h-4 text-white" />
                  </button>
                )}
              </div>
            </div>
          )) : (
            <div className="col-span-2 glass rounded-[40px] py-20 flex flex-col items-center justify-center text-center p-8 space-y-4">
               <Gamepad2 className="w-16 h-16 text-white/5" />
               <p className="text-white/30 font-medium uppercase tracking-widest text-[10px]">
                 {isOwnProfile ? 'Henüz bir oyun yaratmadın.' : 'Henüz oyun yok.'}
               </p>
            </div>
          )}
        </div>
      </div>
    </div>
    </div>
  );
};

const SplashScreen = () => {
  return (
    <div className="fixed inset-0 z-[1000] bg-[#0c0c1e] flex flex-col items-center justify-center p-6">
    <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 to-transparent" />
    
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative z-10 flex flex-col items-center gap-8"
    >
      <div className="w-40 h-40 bg-white/5 backdrop-blur-3xl border border-white/10 rounded-[60px] flex items-center justify-center shadow-[0_40px_80px_rgba(0,0,0,0.4)]">
        <div className="w-28 h-28 bg-gradient-to-tr from-purple-600 to-pink-500 rounded-[45px] flex items-center justify-center">
          <Gamepad2 className="w-14 h-14 text-white animate-bounce" />
        </div>
      </div>
      
      <div className="space-y-4 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-5xl font-black italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-300"
        >
          ASTARA PLAY
        </motion.h1>
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex items-center gap-3 justify-center"
        >
          <div className="h-[2px] w-8 bg-purple-500/30 rounded-full" />
          <p className="text-[10px] font-black uppercase tracking-[0.4em] text-purple-400/60">Loading Universe</p>
          <div className="h-[2px] w-8 bg-purple-500/30 rounded-full" />
        </motion.div>
      </div>
    </motion.div>
    
    <div className="absolute bottom-12 flex flex-col items-center gap-4">
      <Loader2 className="w-6 h-6 text-white/20 animate-spin" />
    </div>
  </div>
  );
};

export default function App() {
  const { user, profile, loading, signInWithGoogle } = useAuth();
  const [activeTab, setActiveTab] = useState<'home' | 'create' | 'profile'>('home');
  const [playingGame, setPlayingGame] = useState<GameData | null>(null);
  const [viewingProfileId, setViewingProfileId] = useState<string | null>(null);

  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const handleToast = (e: any) => setToast(e.detail);
    window.addEventListener('astara-toast', handleToast);
    return () => window.removeEventListener('astara-toast', handleToast);
  }, []);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  useEffect(() => {
    setViewingProfileId(null);
  }, [activeTab]);

  if (loading) return <SplashScreen />;

  if (!user) return <AuthScreen onLogin={() => signInWithGoogle()} />;

  return (
    <div className="fixed inset-0 bg-[#0c0c1e] text-white flex flex-col overflow-hidden max-w-lg mx-auto border-x border-white/5">
      <div className="absolute top-0 inset-x-0 h-64 bg-gradient-to-b from-purple-900/10 to-transparent pointer-events-none" />
      
      {/* Brand Header */}
      <div className="absolute top-6 left-0 right-0 z-50 px-6 flex justify-between items-center pointer-events-none">
        <h1 
          className="text-xl font-black italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-300 pointer-events-auto cursor-pointer"
          onClick={() => setActiveTab('home')}
        >
          ASTARA PLAY
        </h1>
        <div className="flex gap-4 pointer-events-auto items-center">
          <span 
            className={cn("text-xs font-bold uppercase tracking-[0.2em] transition-colors cursor-pointer", activeTab === 'home' ? "text-white" : "text-white/30")}
            onClick={() => setActiveTab('home')}
          >
            FEED
          </span>
          <button 
            onClick={() => setActiveTab('profile')}
            className="w-10 h-10 rounded-full border-2 border-white/20 overflow-hidden bg-white/5 active:scale-90 transition-all"
          >
            {profile?.avatarUrl ? (
              <img 
                src={profile.avatarUrl} 
                className="w-full h-full object-cover" 
                alt="Profile"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${user.uid}`;
                }}
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-tr from-purple-500/40 to-pink-500/40" />
            )}
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 relative overflow-hidden z-10">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div 
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full"
            >
              <HomeFeed onFullscreen={(game) => setPlayingGame(game)} onViewProfile={(uid) => setViewingProfileId(uid)} />
            </motion.div>
          )}
          {activeTab === 'create' && (
            <motion.div 
              key="create"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="h-full"
            >
              <CreateView onDone={() => setActiveTab('home')} />
            </motion.div>
          )}
          {activeTab === 'profile' && (
            <motion.div 
              key="profile"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full"
            >
              <ProfileView onFullscreen={(game) => setPlayingGame(game)} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-32 left-10 right-10 z-[200] flex justify-center pointer-events-none"
          >
            <div className="glass px-6 py-3 rounded-full border-white/20 shadow-2xl bg-purple-500/10 backdrop-blur-3xl">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white whitespace-nowrap">
                {toast}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {viewingProfileId && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[400] bg-[#0c0c1e]"
          >
            <ProfileView 
              userId={viewingProfileId} 
              onFullscreen={(game) => setPlayingGame(game)} 
              onBack={() => setViewingProfileId(null)} 
            />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {playingGame && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[500] bg-black"
          >
            <div className="absolute inset-0">
              <GamePlayer code={playingGame.code} />
            </div>
            
          {/* Minimal Exit Button */}
            <button 
              onClick={() => setPlayingGame(null)}
              className="absolute top-[calc(var(--safe-top)+1rem)] left-6 z-[600] w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-white transition-all shadow-2xl"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation */}
      <div className="h-28 pb-8 px-6 flex items-center justify-around z-[700] relative safe-bottom">
        <div className="absolute inset-x-0 bottom-0 top-0 bg-black border-t border-white/5" />
        
        <button 
          onClick={() => setActiveTab('home')}
          className={cn(
            "flex flex-col items-center gap-1.5 relative z-10 transition-all",
            activeTab === 'home' ? "text-purple-500 scale-110" : "text-white/20 hover:text-white/40"
          )}
        >
          <Home className="w-6 h-6 mb-1" />
          <span className="text-[9px] font-black uppercase tracking-widest leading-none">Keşfet</span>
        </button>

        <button 
          onClick={() => setActiveTab('create')}
          className={cn(
            "flex flex-col items-center gap-1.5 relative z-10 transition-all",
            activeTab === 'create' ? "text-purple-500 scale-110" : "text-white/20 hover:text-white/40"
          )}
        >
          <Play className="w-6 h-6 mb-1" />
          <span className="text-[9px] font-black uppercase tracking-widest leading-none">Üret</span>
        </button>

        <button 
          onClick={() => setActiveTab('profile')}
          className={cn(
            "flex flex-col items-center gap-1.5 relative z-10 transition-all",
            activeTab === 'profile' ? "text-purple-500 scale-110" : "text-white/20 hover:text-white/40"
          )}
        >
          <User className="w-6 h-6 mb-1" />
          <span className="text-[9px] font-black uppercase tracking-widest leading-none">Ben</span>
        </button>
      </div>
    </div>
  );
}
