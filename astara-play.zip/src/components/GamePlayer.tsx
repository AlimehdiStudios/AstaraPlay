import React, { useEffect, useRef } from 'react';

interface GamePlayerProps {
  code: string;
  className?: string;
  onThumbnailCaptured?: (dataUrl: string) => void;
}

export const GamePlayer: React.FC<GamePlayerProps> = ({ code, className, onThumbnailCaptured }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'thumbnail' && onThumbnailCaptured) {
        onThumbnailCaptured(event.data.data);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onThumbnailCaptured]);

  // Inject capture script into the code
  const enhancedCode = `
    ${code}
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
    <script>
      async function captureThumbnail() {
        try {
          const canvas = await html2canvas(document.body, {
            useCORS: true,
            scale: 0.4, // even smaller for faster storage
            logging: false,
            backgroundColor: '#000000'
          });
          window.parent.postMessage({ 
            type: 'thumbnail', 
            data: canvas.toDataURL('image/jpeg', 0.5) 
          }, '*');
        } catch (e) {
          console.error('Capture failed', e);
        }
      }

      window.addEventListener('load', () => {
        setTimeout(captureThumbnail, 1000);
        setTimeout(captureThumbnail, 3000);
        setTimeout(captureThumbnail, 6000);
      });
      
      window.addEventListener('message', (e) => {
        if (e.data === 'capture') {
          captureThumbnail();
        }
      });
    </script>
  `;

  return (
    <div className={`w-full h-full relative bg-black ${className}`}>
      <iframe
        ref={iframeRef}
        title="game-player"
        srcDoc={enhancedCode}
        className="w-full h-full border-none"
        sandbox="allow-scripts allow-modals allow-forms allow-same-origin"
      />
    </div>
  );
};
