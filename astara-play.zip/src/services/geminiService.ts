import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface GeneratedGame {
  code: string;
  title: string;
  description: string;
  thumbnailUrl: string;
}

export async function generateGame(prompt: string): Promise<GeneratedGame> {
  const systemInstruction = `
    You are an expert game developer. Your task is to generate a fully functional, self-contained HTML/JS/CSS game based on the user's prompt.
    
    CRITICAL: 
    1. KEEP THE TOTAL FILE SIZE VERY SMALL (UNDER 500KB).
    2. NEVER include ANY base64 strings for images, audio, or fonts.
    3. Use pure CSS, SVG, or HTML Canvas for all visuals.
    4. The game MUST remain self-contained in a single HTML file using <style> and <script> tags.

    The game should:
    1. Have an interactive game loop.
    2. Be responsive and work within a container.
    3. Include instructions on how to play.
    4. Use modern web APIs (Canvas, DOM, etc.).
    5. Be fun and creative.
    6. DO NOT use external assets (images, sounds) unless they are generic CDN links or SVG. Prefer SVG or Canvas drawing.
    7. Use Turkish language for game text as requested by the user.

    Return the response in JSON format with fields:
    - title: name of the game
    - description: what is the game about
    - code: the full HTML string
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Bir oyun yap: ${prompt}`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          code: { type: Type.STRING }
        },
        required: ["title", "description", "code"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response from Gemini");
  
  const gameData = JSON.parse(text) as any;

  return {
    ...gameData,
    thumbnailUrl: "" 
  } as GeneratedGame;
}

export async function updateGame(currentCode: string, instruction: string): Promise<GeneratedGame> {
  const systemInstruction = `
    You are an expert game developer. Your task is to MODIFY an existing self-contained HTML/JS/CSS game based on the user's instruction.
    
    CRITICAL: 
    1. KEEP THE TOTAL FILE SIZE VERY SMALL (UNDER 500KB).
    2. NEVER include ANY base64 strings for images or audio.
    3. The game MUST remain self-contained in a single HTML file.

    Current Code:
    ${currentCode}

    The modification should:
    1. Keep the game contained in a single HTML file (using <style> and <script> tags).
    2. Maintain or improve the existing functionality while adding/fixing what was requested.
    3. Use Turkish language for any new UI text.
    4. Ensure the game remains responsive.

    Return the response in JSON format with fields:
    - title: name of the game (can keep or update)
    - description: what is the game about now
    - code: the full UPDATED HTML string
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Bu oyunu şu şekilde güncelle: ${instruction}`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          code: { type: Type.STRING }
        },
        required: ["title", "description", "code"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response from Gemini");
  
  const gameData = JSON.parse(text) as any;

  return {
    ...gameData,
    thumbnailUrl: "" // Thumbnail stays the same unless we want to regen it
  } as GeneratedGame;
}
